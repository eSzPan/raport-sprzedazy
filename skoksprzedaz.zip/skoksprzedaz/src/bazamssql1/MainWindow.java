package bazamssql1;
        import java.sql.*;
        import java.text.SimpleDateFormat;
        import java.util.Date;
        import java.util.ArrayList;
        import static bazamssql1.LogWindow.nrpracownika;

/**
 * @author Szczepan Panek
 */
public class MainWindow extends javax.swing.JFrame {
    bazamssql1.LogWindow.DB db;

  public static  int PKPK =34;

    Date myDate = new Date();
    String NOW = new SimpleDateFormat("yyyy-MM-dd").format(myDate);
    String CurrentMonth = new SimpleDateFormat("MM").format(myDate);
    String queryString;
    int columny=2;
    boolean isCheck = true;
    ArrayList<Osoba> lista = new ArrayList<Osoba>();
    Osoba a;
    class Osoba{
        String Id;
        String Pk;
        String Nr_prac;
        String Data;
        int Wn_wyp_ile;
        int Wn_wyp_kw;
        int Wn_w_trakcie_ile;
        int Wn_w_trakcie_kw;
        int Wn_komp_ile;
        int Wn_komp_kw;
        int Lokaty_odn_kw;
        int Nowo_poz_sr_kw;
        int Ubezp_kw;
        int Ror_ile;
    }


    /**
     * Creates new form manWindow
     */
    public MainWindow() {
        initComponents();
        tabela.getTableHeader().setReorderingAllowed(false);
    }
    public void odswiez(){
        int iloscWierszy=0;
        try{

                if (Integer.parseInt(doId.getValue().toString()) == 0)  // jezeli brak doid to podstaw
                {
                    queryString="SELECT MAX(Id) Id  FROM SkokSprzedaz where Nr_prac =" + nrpracownika;
                    ResultSet rs = db.statement.executeQuery(queryString);
                    rs.next();
                    doId.setValue(Integer.parseInt(rs.getString("Id")));
                    podajmiesiac.setValue(Integer.parseInt(CurrentMonth));
                }

                queryString = " Declare @Msc int\n" +
                        "SET @Msc = DATEPART( mm, GETDATE() )\n select Id,Pk,Nr_prac,Data,Wn_wyp_ile,Wn_wyp_kw,Wn_w_trakcie_ile,Wn_w_trakcie_kw," +
                        "Wn_komp_ile,Wn_komp_kw,Lokaty_odn_kw,Nowo_poz_sr_kw,Ubezp_kw," +
                        "Ror_ile from SkokSprzedaz WHERE DATEPART( mm, Data) = " + podajmiesiac.getValue().toString()
                        +" and  Nr_prac =" + nrpracownika + "order by Data";

            ResultSet rs = db.statement.executeQuery(queryString);

            for(int i = 0;rs.next();i++) {
                iloscWierszy++;
                a = new Osoba();
                a.Id = rs.getString("Id");
                a.Pk = rs.getString("Pk");
                a.Nr_prac = rs.getString("Nr_prac");
                a.Data = rs.getString("Data");
                a.Wn_wyp_ile = Integer.parseInt(rs.getString("Wn_wyp_ile"));
                a.Wn_wyp_kw = Integer.parseInt(rs.getString("Wn_wyp_kw"));
                a.Wn_w_trakcie_ile = Integer.parseInt(rs.getString("Wn_w_trakcie_ile"));
                a.Wn_w_trakcie_kw = Integer.parseInt(rs.getString("Wn_w_trakcie_kw"));
                a.Wn_komp_ile = Integer.parseInt(rs.getString("Wn_komp_ile"));
                a.Wn_komp_kw = Integer.parseInt(rs.getString("Wn_komp_kw"));
                a.Lokaty_odn_kw = Integer.parseInt(rs.getString("Lokaty_odn_kw"));
                a.Nowo_poz_sr_kw = Integer.parseInt(rs.getString("Nowo_poz_sr_kw"));
                a.Ubezp_kw = Integer.parseInt(rs.getString("Ubezp_kw"));
                a.Ror_ile = Integer.parseInt(rs.getString("Ror_ile"));
                lista.add(a);
            }

            String   queryString2 = "Declare @Msc int\n" +
                    "SET @Msc = DATEPART( mm, GETDATE() )\n select SUM (Wn_wyp_ile) as sum1, SUM (Wn_wyp_kw) as sum2, SUM (Wn_w_trakcie_ile) as sum3 ," +
                    " SUM (Wn_w_trakcie_kw) as sum4 , SUM (Wn_komp_ile) as sum5, SUM (Wn_komp_kw) as sum6 " +
                    ", SUM (Lokaty_odn_kw) as sum7, SUM (Nowo_poz_sr_kw) as sum8, SUM (Ubezp_kw) as sum9" +
                    ", SUM (Ror_ile) as sum10 from SkokSprzedaz WHERE DATEPART( mm, Data) = "
                    + podajmiesiac.getValue().toString()  +" and Nr_prac =" + nrpracownika;


       ResultSet rs2 = db.statement.executeQuery(queryString2);
          rs2.next();

            iloscWierszy++;
            a = new Osoba();
            a.Id = "-";
            a.Pk = "-";
            a.Nr_prac = "-";
            a.Data = "Suma -";
            a.Wn_wyp_ile = Integer.parseInt(rs2.getString("sum1"));
            a.Wn_wyp_kw = Integer.parseInt(rs2.getString("sum2"));
            a.Wn_w_trakcie_ile = Integer.parseInt(rs2.getString("sum3"));
            a.Wn_w_trakcie_kw = Integer.parseInt(rs2.getString("sum4"));
            a.Wn_komp_ile = Integer.parseInt(rs2.getString("sum5"));
            a.Wn_komp_kw = Integer.parseInt(rs2.getString("sum6"));
            a.Lokaty_odn_kw = Integer.parseInt(rs2.getString("sum7"));
            a.Nowo_poz_sr_kw = Integer.parseInt(rs2.getString("sum8"));
            a.Ubezp_kw = Integer.parseInt(rs2.getString("sum9"));
            a.Ror_ile = Integer.parseInt(rs2.getString("sum10"));
            lista.add(a);
//###################################
            int s1 = Integer.parseInt(rs2.getString("sum1"));
            int s2 = Integer.parseInt(rs2.getString("sum2"));
            int s3 = Integer.parseInt(rs2.getString("sum3"));
            int s4 = Integer.parseInt(rs2.getString("sum4"));
            int s5 = Integer.parseInt(rs2.getString("sum5"));
            int s6 = Integer.parseInt(rs2.getString("sum6"));
            int s7 = Integer.parseInt(rs2.getString("sum7"));
            int s8 = Integer.parseInt(rs2.getString("sum8"));
            int s9 = Integer.parseInt(rs2.getString("sum9"));
            int s10 = Integer.parseInt(rs2.getString("sum10"));
//###################################
            String   queryString3 = "Declare @Msc int\n" +
                    "SET @Msc = DATEPART( mm, GETDATE() )\n select Id,Nr_prac,Data,Wn_wyp_ile,Wn_wyp_kw,Wn_w_trakcie_ile,Wn_w_trakcie_kw," +
                    "Wn_komp_ile,Wn_komp_kw,Lokaty_odn_kw,Nowo_poz_sr_kw,Ubezp_kw," +
                    "Ror_ile from SprzedazLimity WHERE  Nr_prac = " + nrpracownika;

            ResultSet rs3 = db.statement.executeQuery(queryString3);
            rs3.next();
            iloscWierszy++;
            a = new Osoba();
            a.Id = "-";
            a.Pk = "-";
            a.Nr_prac = "-";
            a.Data = "% Wykonania planu";
            a.Wn_wyp_ile = (int) ((float) s1/ Integer.parseInt(rs3.getString("Wn_wyp_ile"))*100);
            a.Wn_wyp_kw  = (int) ((float) s2/ Integer.parseInt(rs3.getString("Wn_wyp_kw"))*100);
            a.Wn_w_trakcie_ile  = (int) ((float) s3/ Integer.parseInt(rs3.getString("Wn_w_trakcie_ile"))*100);
            a.Wn_w_trakcie_kw = (int) ((float) s4/ Integer.parseInt(rs3.getString("Wn_w_trakcie_kw"))*100);
            a.Wn_komp_ile = (int) ((float) s5/ Integer.parseInt(rs3.getString("Wn_komp_ile"))*100);
            a.Wn_komp_kw = (int) ((float) s6/ Integer.parseInt(rs3.getString("Wn_komp_kw"))*100);
            a.Lokaty_odn_kw = (int) ((float) s7/ Integer.parseInt(rs3.getString("Lokaty_odn_kw"))*100);
            a.Nowo_poz_sr_kw = (int) ((float) s8/ Integer.parseInt(rs3.getString("Nowo_poz_sr_kw"))*100);
            a.Ubezp_kw = (int) ((float) s9/ Integer.parseInt(rs3.getString("Ubezp_kw"))*100);
            a.Ror_ile = (int) ((float) s10/ Integer.parseInt(rs3.getString("Ror_ile"))*100);
            lista.add(a);

            tabela.setModel(new javax.swing.table.DefaultTableModel(
                   new Object [iloscWierszy][16] ,
                    new String [] {
                            "Lp.", "Check", "Id", "Pk", "Nr_prac", "Data", "Wn_wyp_ile","Wn_wyp_kw",
                            "Wn_w_trakcie_ile", "Wn_w_trakcie_kw", "Wn_komp_ile", "Wn_komp_kw",
                            "Lokaty_odn_kw","Nowo_poz_sr_kw","Ubezp_kw","Ror_ile"   // TABLICA W ODSWIEZ
                    }
            ) {
                Class[] types = new Class [] {
                        java.lang.Object.class, java.lang.Boolean.class, java.lang.Integer.class,
                        java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class,
                        java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class,
                        java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class,
                        java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class,
                        java.lang.Integer.class,java.lang.Integer.class
                };
                boolean[] canEdit = new boolean [] {
                        true, true, false, true, true, true , true , true,
                        true, true, true, true , true , true, true , true
                };

                public Class getColumnClass(int columnIndex) {
                    return types [columnIndex];
                }

                public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
                }
            });
            for(int i = 0;i<iloscWierszy;i++) {

                tabela.getModel().setValueAt(i+1, i, columny-2);
                tabela.getModel().setValueAt(lista.get(i).Id, i, columny);
                tabela.getModel().setValueAt(lista.get(i).Pk, i, columny+1);
                tabela.getModel().setValueAt(lista.get(i).Nr_prac, i, columny+2);
                tabela.getModel().setValueAt(lista.get(i).Data, i, columny+3);
                tabela.getModel().setValueAt(lista.get(i).Wn_wyp_ile, i, columny+4);
                tabela.getModel().setValueAt(lista.get(i).Wn_wyp_kw, i, columny+5);
                tabela.getModel().setValueAt(lista.get(i).Wn_w_trakcie_ile, i, columny+6);
                tabela.getModel().setValueAt(lista.get(i).Wn_w_trakcie_kw, i, columny+7);
                tabela.getModel().setValueAt(lista.get(i).Wn_komp_ile, i, columny+8);
                tabela.getModel().setValueAt(lista.get(i).Wn_komp_kw, i, columny+9);
                tabela.getModel().setValueAt(lista.get(i).Lokaty_odn_kw, i, columny+10);
                tabela.getModel().setValueAt(lista.get(i).Nowo_poz_sr_kw, i, columny+11);
                tabela.getModel().setValueAt(lista.get(i).Ubezp_kw, i, columny+12);
                tabela.getModel().setValueAt(lista.get(i).Ror_ile, i, columny+13);

            }
            lista.clear();
        }catch(Exception e){
            e.printStackTrace();
        }

    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dodajWindow = new javax.swing.JFrame();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaDodaj = new javax.swing.JTable();
        dodajOsobeButton = new javax.swing.JButton();
        alertWindow = new javax.swing.JFrame();
        jScrollPane3 = new javax.swing.JScrollPane();
        logText = new javax.swing.JTextArea();
        tabelaPopMenu = new javax.swing.JPopupMenu();
        odswiezItem = new javax.swing.JMenuItem();
        dodajItem = new javax.swing.JMenuItem();
        usunItem = new javax.swing.JMenuItem();
        edytujItem = new javax.swing.JMenuItem();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        odswiezButton = new javax.swing.JButton();
        dodajButton = new javax.swing.JButton();
        usunButton = new javax.swing.JButton();
        edytujButton = new javax.swing.JButton();
        zakonczButton = new javax.swing.JButton();
        odId = new javax.swing.JSpinner();
        doId = new javax.swing.JSpinner();
        podajmiesiac = new javax.swing.JSpinner();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        dodajWindow.setSize(new java.awt.Dimension(1300, 400));
        dodajWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                dodajWindowWindowClosing(evt);
            }
        });
// dobra tabelka
        tabelaDodaj.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                        {null, null, null, null, null, null, null, null, null, null, null, null}
                },
                new String [] {
                        "Nr_prac","D. rrrr-mm-dd","Wn_wyp_ile","Wn_wyp_kw","Wn_w_trakcie_ile","Wn_w_trakcie_kw",
                        "Wn_komp_ile","Wn_komp_kw","Lokaty_odn_kw","Nowo_poz_sr_kw","Ubezp_kw","Ror_ile"
                }
        ) {
            Class[] types = new Class [] {
                    java.lang.String.class, java.lang.String.class, java.lang.String.class
                    , java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
                    , java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
                    , java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tabelaDodaj);

        dodajOsobeButton.setText("Zatwierdź");
        dodajOsobeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dodajOsobeButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout dodajWindowLayout = new javax.swing.GroupLayout(dodajWindow.getContentPane());
        dodajWindow.getContentPane().setLayout(dodajWindowLayout);
        dodajWindowLayout.setHorizontalGroup(
                dodajWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(dodajWindowLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(dodajWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(dodajOsobeButton))
                                .addContainerGap(15, Short.MAX_VALUE))
        );
        dodajWindowLayout.setVerticalGroup(
                dodajWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(dodajWindowLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dodajOsobeButton)
                                .addContainerGap(213, Short.MAX_VALUE))
        );

        alertWindow.setSize(new java.awt.Dimension(400, 400));
        alertWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                alertWindowWindowClosing(evt);
            }
        });

        logText.setEditable(false);
        logText.setColumns(35);
        logText.setRows(38);
        jScrollPane3.setViewportView(logText);

        javax.swing.GroupLayout alertWindowLayout = new javax.swing.GroupLayout(alertWindow.getContentPane());
        alertWindow.getContentPane().setLayout(alertWindowLayout);
        alertWindowLayout.setHorizontalGroup(
                alertWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(alertWindowLayout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(111, Short.MAX_VALUE))
        );
        alertWindowLayout.setVerticalGroup(
                alertWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(alertWindowLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(152, Short.MAX_VALUE))
        );

        odswiezItem.setText("Odśwież");
        odswiezItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                odswiezItemActionPerformed(evt);
            }
        });
        tabelaPopMenu.add(odswiezItem);

        dodajItem.setText("Dodaj");
        dodajItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dodajItemActionPerformed(evt);
            }
        });
        tabelaPopMenu.add(dodajItem);

        usunItem.setText("Usuń zaznaczone");
        usunItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usunItemActionPerformed(evt);
            }
        });
        tabelaPopMenu.add(usunItem);

  /*      edytujItem.setText("Edytuj Zaznaczone");
        edytujItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edytujItemActionPerformed(evt);
            }
        });
        tabelaPopMenu.add(edytujItem);
*/
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        // ta tabelka gdy brak danych
        podajmiesiac.setValue(Integer.parseInt(CurrentMonth));
        tabela.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                        {null, null, null, null, null, null, null, null, null, null, null, null}
                },
                new String [] {
                        "Nr_prac","D. rrrr-mm-dd","Wn_wyp_ile","Wn_wyp_kw","Wn_w_trakcie_ile","Wn_w_trakcie_kw",
                        "Wn_komp_ile","Wn_komp_kw","Lokaty_odn_kw","Nowo_poz_sr_kw","Ubezp_kw","Ror_ile"
                }
        ) {
            Class[] types = new Class [] {
                    java.lang.String.class, java.lang.String.class, java.lang.String.class
                    , java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
                    , java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
                    , java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                    true, true, false, true, true, true, true, true, true, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela.setComponentPopupMenu(tabelaPopMenu);
        tabela.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                tabelaComponentAdded(evt);
            }
        });
        jScrollPane1.setViewportView(tabela);

        odswiezButton.setText("Odśwież");
        odswiezButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                odswiezButtonActionPerformed(evt);
            }
        });

        dodajButton.setText("Wprowadź dane");
        dodajButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dodajButtonActionPerformed(evt);
            }
        });

        usunButton.setText("usuń zaznaczone");
        usunButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usunButtonActionPerformed(evt);
            }
        });

        zakonczButton.setText("zakończ");
        zakonczButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                koniecButtonActionPerformed(evt);
            }
        });
 /*       edytujButton.setText("Edytuj Zaznaczone");
        edytujButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edytujButtonActionPerformed(evt);
            }
        });
*/
        odId.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                odIdStateChanged(evt);
            }
        });

        jLabel1.setText("Od Id:");
        jLabel2.setText("Do Id:");
        jLabel3.setText("Miesiąc");

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Nowy");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Koniec");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Pomoc");
// Sz
        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Info");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);




        jMenuBar1.add(jMenu2);
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                        //        .addComponent(jLabel1)
                        //        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        //        .addComponent(odId, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                         //       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        //        .addComponent(jLabel2)
                         //       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                         //       .addComponent(doId, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3)
                                .addComponent(podajmiesiac, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1300, Short.MAX_VALUE)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(odswiezButton)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(dodajButton)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(usunButton)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(zakonczButton, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             //   .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                             //   .addComponent(edytujButton)
                                                .addGap(0, 0, Short.MAX_VALUE)))
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                 //       .addComponent(odId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                //        .addComponent(doId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                //        .addComponent(jLabel1)
                                //        .addComponent(jLabel2)
                                        .addComponent(jLabel3)
                                        .addComponent(podajmiesiac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)

                                )
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(dodajButton)
                                        .addComponent(odswiezButton)
                                        .addComponent(usunButton)
                                        .addComponent(zakonczButton)
                               //         .addComponent(edytujButton))
                                .addGap(0, 8, Short.MAX_VALUE))
        ));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void odswiezButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_odswiezButtonActionPerformed

        this.odswiez();

        // TODO add your handling code here:
    }//GEN-LAST:event_odswiezButtonActionPerformed


    private void zakonczItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usunItemActionPerformed
        zakonczButton.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_usunItemActionPerformed


    private void koniecButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_koniecButtonActionPerformed

        this.dispose();

    }


    private void dodajButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dodajButtonActionPerformed
        dodajWindow.setVisible(true);
        this.setEnabled(false);
        tabelaDodaj.getModel().setValueAt(nrpracownika, 0, 0);
        tabelaDodaj.getModel().setValueAt(NOW, 0, 1);
        tabelaDodaj.getModel().setValueAt(null, 0, 2);
        tabelaDodaj.getModel().setValueAt(null, 0, 3);
        tabelaDodaj.getModel().setValueAt(null, 0, 4);
        tabelaDodaj.getModel().setValueAt(null, 0, 5);
        tabelaDodaj.getModel().setValueAt(null, 0, 6);
        tabelaDodaj.getModel().setValueAt(null, 0, 7);
        tabelaDodaj.getModel().setValueAt(null, 0, 8);
        tabelaDodaj.getModel().setValueAt(null, 0, 9);
        tabelaDodaj.getModel().setValueAt(null, 0, 10);
        tabelaDodaj.getModel().setValueAt(null, 0, 11);

        // TODO add your handling code here:
    }

    public void dodajOsobeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dodajOsobeButtonActionPerformed

        isCheck=true;
        logText.setText("Uwaga! Wszystkie pola muszą być\n" +
                "na niebieskim tle (zatwierdzone tab lub enterem)\nBłędy: \n");
        if (tabelaDodaj.getModel().getValueAt(0, 0)==null){
            isCheck=false;
            logText.append("nie wpisany Nr_prac \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 1)==null){
            isCheck=false;
            logText.append("nie wpisana Data \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 2)==null){
            isCheck=false;
            logText.append("nie wpisane Wn_wyp_ile \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 3)==null){
            isCheck=false;
            logText.append("nie wpisane Wn_wyp_kw \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 4)==null) {
            isCheck = false;
            logText.append("nie wpisane Wn_w_trakcie_ile \n");
        }
            if (tabelaDodaj.getModel().getValueAt(0, 5)==null) {
                isCheck = false;
                logText.append("nie wpisane Wn_w_trakcie_kw \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 6)==null) {
            isCheck = false;
            logText.append("nie wpisane Wn_komp_ile \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 7)==null) {
            isCheck = false;
            logText.append("nie wpisane Wn_komp_kw \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 8)==null) {
            isCheck = false;
            logText.append("nie wpisane Lokaty_odn_kw \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 9)==null) {
            isCheck = false;
            logText.append("nie wpisane Nowo_poz_sr_kw \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 10)==null) {
            isCheck = false;
            logText.append("nie wpisane Ubezp_kw \n");
        }
        if (tabelaDodaj.getModel().getValueAt(0, 11)==null) {
            isCheck = false;
            logText.append("nie wpisane Ror_ile \n");
        }

        if(isCheck){
            try{
                queryString="SELECT MAX(Id) Id  FROM SkokSprzedaz where Nr_prac =" + nrpracownika;
                ResultSet rs1 = db.statement.executeQuery(queryString);
                rs1.next();
                int a=0;
                if(rs1.getString("Id")==null) {
                    a=1;
                } else {
                    a = Integer.parseInt(rs1.getString("Id"))+1;
                };

                queryString = "INSERT INTO SkokSprzedaz(Id, Pk, Nr_prac ,Data, Wn_wyp_ile, Wn_wyp_kw, " +
                        "Wn_w_trakcie_ile, Wn_w_trakcie_kw, Wn_komp_ile, Wn_komp_kw, Lokaty_odn_kw,Nowo_poz_sr_kw,Ubezp_kw,Ror_ile) VALUES ("
                        + a +",'" + PKPK  +"',"
                        + tabelaDodaj.getModel().getValueAt(0, 0)+",'"
                        + tabelaDodaj.getModel().getValueAt(0, 1)+"',"
                        + tabelaDodaj.getModel().getValueAt(0, 2)+","
                        + tabelaDodaj.getModel().getValueAt(0, 3)+","
                        + tabelaDodaj.getModel().getValueAt(0, 4)+","
                        + tabelaDodaj.getModel().getValueAt(0, 5)+","
                        + tabelaDodaj.getModel().getValueAt(0, 6)+","
                        + tabelaDodaj.getModel().getValueAt(0, 7)+","
                        + tabelaDodaj.getModel().getValueAt(0, 8)+","
                        + tabelaDodaj.getModel().getValueAt(0, 9)+","
                        + tabelaDodaj.getModel().getValueAt(0, 10)+","
                        + tabelaDodaj.getModel().getValueAt(0, 11)+")";

                int doid2 = Integer.parseInt(doId.getValue().toString());
                doid2++;
                doId.setValue(doid2);
                db.statement.executeUpdate(queryString);
                this.setEnabled(true);
                dodajWindow.dispose();
            }catch(Exception e){
                e.printStackTrace();
            }
            this.odswiez();
        }else {
            alertWindow.setVisible(true);
            dodajWindow.setEnabled(false);
            this.setEnabled(false);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_dodajOsobeButtonActionPerformed

    private void alertWindowWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_alertWindowWindowClosing
        dodajWindow.setEnabled(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_alertWindowWindowClosing

    private void dodajWindowWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_dodajWindowWindowClosing
        this.setEnabled(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_dodajWindowWindowClosing




    private void usunButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usunButtonActionPerformed
        String lap="";
        int countTrue=0;
        for(int i=0;i<tabela.getRowCount();i++){
            if((tabela.getModel().getValueAt(i, columny -1)!=null)&&(tabela.getModel().getValueAt(i, columny)!=null)){
                if (tabela.getModel().getValueAt(i, columny-1).toString()=="true"){
                    countTrue++;
                    if (countTrue==1) {
                        lap=tabela.getModel().getValueAt(i, columny).toString();
                    }else{
                        lap=lap+" or Id="+tabela.getModel().getValueAt(i, columny).toString();
                    }

                }
            }
            tabela.getModel().setValueAt(false, i, columny-1);

        }

        if (countTrue>0){
            try{
                queryString = "DELETE FROM SkokSprzedaz  WHERE Id="+lap + " and Nr_prac = " + nrpracownika;
                db.statement.executeUpdate(queryString);
            }catch(Exception e){
                e.printStackTrace();
            }
            this.odswiez();
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_usunButtonActionPerformed



    private void odIdStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_odIdStateChanged

        // TODO add your handling code here:
    }//GEN-LAST:event_odIdStateChanged

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        LogWindow a;
        a = new LogWindow();
        a.setVisible(true);
        this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
    //    JOptionPane.showMessageDialog(null,"Autor Szczepan Panek,\nwersja 1.1 2016 r.");
        this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {
        logText.setText("Dzienny raport sprzedaży\n\n" +
                "Za pomocą przycisku 'Wprowadź Dane' \n" +
                "należy wprowadzić następujące pozycje:\n" +
                "Wn_wyp_ile czyli Wnioski wypełnione ilość \n" +
                "Wn_wyp_kw czyli Wnioski wypełnione kwota \n" +
                "Wn_w_trakcie_ile czyli Wnioski niezatwierdzone ilość \n" +
                "Wn_w_trakcie_kw czyli Wnioski niezatwierdzone kwota\n" +
                "Wn_komp_ile czyli Wnioski kompletne ilość \n" +
                "Wn_komp_kw czyli Wnioski kompletne kwota \n" +
                "Lokaty_odn_kw czyli Lokaty odnawialne kwota\n" +
                "Nowo_poz_sr_kw czyli nowo pozyskane środki kwota\n" +
                "Ubezp_kw czyli Ubezpieczenia kwota\n" +
                "Ror_ile czyli ilość nowo założonych ROR\n\n" +
                "Wszystkie pozycje muszą być wypełnione,\n" +
                "w razie pustych pozycji należy wprowadzić cyfrę 0.\n" +
                "Zatwierdzamy wpis za pomocą przycisku 'zatwierdź'.\n" +
                "W razie pomyłki zaznaczamy rekord\n" +
                "w kolumnie 'Check' i kasujemy poprzez klawisz \n " +
                "usuń zaznaczone \n");
        alertWindow.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void odswiezItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_odswiezItemActionPerformed
        odswiezButton.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_odswiezItemActionPerformed

    private void dodajItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dodajItemActionPerformed
        dodajButton.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_dodajItemActionPerformed

    private void usunItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usunItemActionPerformed
        usunButton.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_usunItemActionPerformed

    private void edytujItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edytujItemActionPerformed
        edytujButton.doClick();
        // TODO add your handling code here:
    }//GEN-LAST:event_edytujItemActionPerformed

    private void tabelaComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_tabelaComponentAdded
        if(tabela.isColumnSelected(columny+1)||tabela.isColumnSelected(columny+2)||tabela.isColumnSelected(columny+3)){
            for(int i=0;i<tabela.getRowCount();i++){
                if (tabela.getModel().getValueAt(i, columny)!=null){
                    if(tabela.isRowSelected(i)){
                        tabela.getModel().setValueAt(true, i, columny-1);
                    }
                }
            }

        }
        // TODO add your handling code here:
    }//GEN-LAST:event_tabelaComponentAdded

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainWindow().setVisible(true);
            }
        });
    }
    private javax.swing.JFrame alertWindow;
    private javax.swing.JSpinner odId;
    private javax.swing.JSpinner doId;
    private javax.swing.JSpinner podajmiesiac;
    private javax.swing.JButton dodajButton;
    private javax.swing.JMenuItem dodajItem;
    private javax.swing.JButton dodajOsobeButton;
    private javax.swing.JFrame dodajWindow;
    private javax.swing.JButton edytujButton;
    private javax.swing.JMenuItem edytujItem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea logText;
    private javax.swing.JButton odswiezButton;
    private javax.swing.JMenuItem odswiezItem;
    private javax.swing.JTable tabela;
    private javax.swing.JTable tabelaDodaj;
    private javax.swing.JPopupMenu tabelaPopMenu;
    private javax.swing.JButton usunButton;
    private javax.swing.JMenuItem usunItem;
    private javax.swing.JButton zakonczButton;
}
